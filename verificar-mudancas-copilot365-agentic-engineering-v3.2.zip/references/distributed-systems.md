# Sistemas distribuídos
Não assumir exactly-once. Avaliar duplicidade, ordem, retries, idempotência, DLQ, consistência eventual, timeout, falhas parciais, correlação e recuperação.
