# Mensageria e event-driven

Mapear producer → broker/topic/queue → consumer → side effects.

Verificar:
- delivery semantics;
- ordering;
- partition key;
- consumer group;
- idempotência;
- retries;
- poison messages;
- DLQ;
- visibility/ack;
- schema/versioning;
- replay;
- lag/backlog;
- duplicidade;
- correlation id.

Não assumir exatamente-once ponta a ponta sem evidência.
