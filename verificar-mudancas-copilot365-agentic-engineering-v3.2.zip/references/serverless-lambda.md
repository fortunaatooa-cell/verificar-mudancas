# Serverless / AWS Lambda

Separar:
- package/layer size;
- unzip/import/init;
- cold start;
- memória configurada;
- CPU proporcional quando aplicável;
- duração/timeout;
- /tmp;
- conexões;
- concorrência;
- payload/event size;
- limits/quotas;
- arquitetura x86_64/arm64;
- dependências nativas.

Para PyArrow/Pandas/AWS SDK for pandas, validar wheels, arquitetura, layer real, imports usados e medição de memória.
Não remover biblioteca apenas pelo tamanho sem provar relação com a falha.
