# Rede e Load Balancers

Diagnóstico por camadas:
DNS → route → firewall/SG/NACL → listener → TLS → LB → target group → porta → aplicação → auth/path.

401 normalmente indica que a requisição chegou a uma camada HTTP/aplicação; não trate automaticamente como falha de conectividade.

Health check precisa refletir readiness real e não depender de autenticação inadequada.

Em TLS, separar terminação no LB, passthrough e re-encryption.
