# Perfil regulado
Preservar rastreabilidade, evidência, versionamento, aprovação humana e restrições de mudança.
Não substituir validação profissional/legal/normativa exigida.
Diferenciar recomendação técnica, evidência e aprovação formal.
