# Segurança
Modelo: ativo → ator/entrada → trust boundary → privilégio → ameaça → controle → evidência.
Ativar para authn/authz, IAM, secrets, input externo, SQL, uploads, rede, dependências, criptografia e dados/logs sensíveis.
Preferir teste negativo específico. Ausência de finding não prova segurança.
