# CI/CD e release
Confirmar branch, artifact, ambiente, config/secrets, etapa que falhou e evidência pós-deploy.
CI verde prova somente o pipeline executado.
Deploy concluído não prova saúde; usar smoke/health/runtime quando pertinente.
