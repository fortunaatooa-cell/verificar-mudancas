# APIs e contratos
Verificar método, path, status, headers, content type, schema, erros, versionamento, compatibilidade, idempotência, timeout/retry e consumidor real.
Mocks não substituem prova do contrato quebrado quando a falha está na integração real.
