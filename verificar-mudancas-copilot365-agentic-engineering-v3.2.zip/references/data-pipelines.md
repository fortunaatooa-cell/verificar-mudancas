# Pipelines de dados

Avaliar:
- source of truth;
- watermark/checkpoint;
- at-least-once;
- deduplicação;
- schema evolution;
- late/out-of-order data;
- partial failure;
- retry/replay;
- backfill;
- reconciliação;
- lineage;
- qualidade;
- observabilidade por lote/partição.

Reprocessamento precisa ser idempotente ou ter estratégia explícita para duplicidade.
