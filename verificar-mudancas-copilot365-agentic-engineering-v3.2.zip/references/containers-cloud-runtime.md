# Containers e cloud runtime
Distinguir build image, artifact, startup, readiness/liveness, limites CPU/memória, rede, DNS, portas, filesystem e sinais de plataforma.
Em kill de container, separar limite externo de OOM interno da aplicação.
