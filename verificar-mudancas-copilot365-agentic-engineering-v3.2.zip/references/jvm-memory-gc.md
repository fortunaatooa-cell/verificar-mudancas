# JVM, memória e GC

Separar:
- heap;
- metaspace;
- code cache;
- thread stacks;
- direct buffers;
- native allocations/JNI;
- mapped files;
- JVM overhead;
- page cache/RSS do container.

Diagnóstico:
1. Identifique quem matou/falhou: JVM, kernel/cgroup, plataforma ou aplicação.
2. Colete limite e uso real.
3. Observe GC pauses, allocation rate, promotion, old-gen occupancy e threads.
4. Heap dump/profile somente quando autorizado e viável.
5. Correlacione timestamps entre aplicação e plataforma.

`-Xmx` não representa RSS total.
Reduzir dependência pode reduzir artefato sem reduzir proporcionalmente memória runtime.
