# AWS Engineering

Antes de mudanças:
- conta;
- região;
- VPC/subnets;
- security groups/NACL quando pertinentes;
- IAM role/policy;
- quotas;
- tags/ownership;
- ambiente.

Para ALB/NLB/TG:
- listener/protocol/TLS;
- target type/port;
- health-check protocol/path/status;
- SG/NACL/route;
- host/header/auth;
- target registration e state.

Para S3/Lambda/DynamoDB/SQS/SNS/API Gateway/Glue:
validar limites, retries, IAM, event source, idempotência e observabilidade específicos.
