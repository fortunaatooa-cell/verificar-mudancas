# Python
Confirmar versão, ambiente, lock/requirements, dependências nativas, OS/arquitetura.
Em serverless/container separar package/layer size, import time, cold start, memória do processo, /tmp, duração e limites da plataforma.
Não inferir RAM pelo tamanho de biblioteca.
