# Java e Spring
Confirmar Java, Spring/Spring Boot, Maven/Gradle, versões e profiles.
Distinguir configuração/binding, serialização, Feign/HTTP, transação, bean/context, persistência, mensageria, concorrência e incompatibilidade de versão.
Compilação não prova contrato HTTP/integrado. Para endpoint, buscar prova na fronteira HTTP quando relevante.
