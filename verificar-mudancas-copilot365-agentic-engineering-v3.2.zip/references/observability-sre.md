# Observabilidade e SRE

Use a pergunta: qual sinal permitiria detectar, localizar e comprovar esta falha?

Logs:
- timestamp consistente;
- severity;
- correlation/trace id;
- campos estruturados;
- erro com contexto sem segredo.

Métricas:
- RED: rate, errors, duration;
- USE: utilization, saturation, errors;
- fila: depth, age, retry/DLQ;
- JVM: heap, GC, threads;
- banco: connections, latency, locks.

Traces:
- spans em fronteiras reais;
- propagação de contexto;
- dependência lenta/erro parcial.

Alerta deve ser acionável e ligado a impacto, não apenas a ruído técnico.
