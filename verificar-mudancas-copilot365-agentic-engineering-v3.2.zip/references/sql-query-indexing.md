# SQL, queries e índices

Antes de criar índice:
1. identifique query real;
2. examine filtros, joins, ordenação e cardinalidade;
3. obtenha plano de execução quando possível;
4. avalie seletividade e custo de escrita;
5. considere índice composto e ordem das colunas;
6. valide antes/depois.

Procure:
- full scans inesperados;
- N+1;
- funções que impedem uso de índice;
- paginação com OFFSET extrema;
- locks longos;
- queries sem limite;
- pool esgotado.

Índice melhora algumas leituras e pode piorar escrita/storage.
