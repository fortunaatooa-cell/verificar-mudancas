# Bancos e migrações
Avaliar schema, nullability, constraints, índices, plano de query, transações, isolamento, locks, concorrência, migração, coexistência de versões, backfill, replay, reconciliação, rollback/rollforward e risco destrutivo.
