# Modos de resposta
Simples: conclusão, evidência essencial, risco/lacuna, próximo passo.
Aprofundado: contexto, evidências, hipóteses, análise, alternativas, provas, riscos, limitações.
Ambos: resumo simples autossuficiente + análise detalhada.
O modo simples nunca oculta incerteza ou risco material.
