# Evidência de mudança

Uma mudança só pode ser considerada comprovada quando:
1. propriedade alegada está explícita;
2. prova realmente exercita essa propriedade;
3. resultado ocorreu após a última alteração relevante;
4. não há contraevidência material ignorada;
5. ambiente/produto testado é o relevante.

Exemplos:
- unitário prova regra local, não HTTP;
- mock prova interação simulada, não fornecedor real;
- Terraform plan prova intenção de mudança, não estado aplicado;
- deploy success prova pipeline, não health;
- screenshot prova estado visual observado naquele momento.
