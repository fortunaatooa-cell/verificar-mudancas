# Performance, observabilidade e SRE
Definir métrica/baseline: latência p50/p95/p99, throughput, CPU, memória, GC, I/O, cold start.
Comparar cenários equivalentes.
Usar logs, métricas, traces, health checks e eventos para achar primeiro sinal da degradação.
Considerar timeout, retry limitado, backoff/jitter, circuit breaker, backpressure, capacidade e rollback signal.
