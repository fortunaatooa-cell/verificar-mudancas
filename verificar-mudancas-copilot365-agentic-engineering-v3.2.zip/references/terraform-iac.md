# Terraform / IaC
Distinguir configuração desejada, plan e estado implantado.
Antes de apply/ação externa: confirmar conta, região, workspace, target, permissões, replacement/destruição e recuperação.
Plan é evidência de mudança proposta, não runtime aplicado.
