# Frontend/UI/E2E
Para comportamento visível, testar fluxo do usuário e integração necessária; unitário isolado não prova UX.
Considerar estados loading/error/empty, acessibilidade, contrato backend, browser/runtime e regressão visual quando pertinente.
