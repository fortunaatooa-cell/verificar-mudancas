# Desenhos técnicos
Identificar tipo/finalidade, título/revisão, escala/unidade, legenda, vistas/cortes, componentes, IDs, conexões, direção, interfaces, dimensões e notas.
Separar observado/inferido/não determinável.
Cross-check com código/Terraform/config/spec/BOM.
Criação: Mermaid/PlantUML/DOT, SVG ou CAD/script quando houver dados suficientes.
