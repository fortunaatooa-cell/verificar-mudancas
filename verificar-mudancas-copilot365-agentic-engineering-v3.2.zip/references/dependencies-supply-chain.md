# Dependências e supply chain
Confirmar versão, origem, lockfile, transitivas, breaking changes, advisories e compatibilidade.
Não trocar/remover dependência apenas por tamanho sem provar impacto relevante.
