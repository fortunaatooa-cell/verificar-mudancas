# Arquitetura e refatoração

Refatoração deve preservar comportamento contratado.

Antes:
- definir baseline;
- proteger contrato;
- mapear dependências/coupling;
- identificar razão concreta.

Durante:
- passos pequenos;
- compatibilidade;
- strangler/coexistência quando útil.

Depois:
- regressão;
- comparação de contrato;
- remover legado somente com evidência.

Arquitetura não deve ser alterada por moda; conecte proposta a forças mensuráveis.
