# Migração zero/baixo downtime

Prefira expand/contract:
1. expandir schema compatível;
2. publicar código que suporte coexistência;
3. backfill/reconciliação;
4. trocar leitura/escrita;
5. observar;
6. remover legado somente depois.

Evite renomear/remover coluna em uma única etapa quando versões antigas ainda podem executar.

Defina:
- compatibilidade N/N-1;
- rollback/rollforward;
- duração do backfill;
- limite de lock;
- verificação de integridade.
