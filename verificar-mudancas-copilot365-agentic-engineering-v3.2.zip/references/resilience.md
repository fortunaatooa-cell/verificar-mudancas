# Resiliência

Retries somente para falhas potencialmente transitórias e operações compatíveis com repetição.

Sempre considerar:
- timeout explícito;
- retry limitado;
- backoff/jitter;
- idempotência;
- circuit breaker;
- bulkhead;
- backpressure;
- DLQ;
- fallback que não masque corrupção;
- budget total de tempo.

Retry em erro permanente pode amplificar incidente.
Fallback silencioso pode esconder perda de dados.
