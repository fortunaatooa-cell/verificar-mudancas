# Playbook — Memória / OOM
1. Identifique processo e mecanismo da falha.
2. Diferencie JVM OOM, container/cgroup kill e limite da plataforma.
3. Registre limite, pico/steady state e momento.
4. Separe heap/native/metaspace/threads/direct buffers quando JVM.
5. Formule hipóteses.
6. Meça/profiling quando possível.
7. Faça menor correção.
8. Compare antes/depois.
