# Regressão de performance
Baseline → métrica → ponto de mudança → telemetria/profile → hipótese → benchmark controlado → correção → comparação final.