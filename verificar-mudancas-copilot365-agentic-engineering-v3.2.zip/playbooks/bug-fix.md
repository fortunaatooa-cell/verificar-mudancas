# Bug fix
Esperado/observado → reproduzir/evidenciar → hipóteses → RED/prova → menor correção → regressão → review → verificação final.