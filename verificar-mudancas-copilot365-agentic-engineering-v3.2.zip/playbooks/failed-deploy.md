# Playbook — Deploy falhou / app não sobe
1. Identifique fase: build, artifact, deploy, startup, readiness, traffic.
2. Pegue primeiro erro causal.
3. Confirme versão/config/secrets/target.
4. Diferencie deploy concluído de health.
5. Corrija menor causa.
6. Reexecutar e validar health + smoke.
