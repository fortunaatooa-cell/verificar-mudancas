# Playbook — Regressão de latência
1. Defina endpoint/fluxo e percentil afetado.
2. Compare release/carga/ambiente.
3. Quebre tempo por camada.
4. Use trace/metrics/profile.
5. Teste hipótese controlada.
6. Corrija gargalo.
7. Refaça benchmark equivalente e valide p95/p99.
