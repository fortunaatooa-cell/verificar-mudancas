# Upgrade de dependência
Versão atual/alvo → breaking changes/advisories → transitivas → testes/contratos → rollout → rollback.