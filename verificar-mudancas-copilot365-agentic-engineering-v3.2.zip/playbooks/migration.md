# Migração
Estado atual/alvo → compatibilidade/coexistência → plano → backfill/migração → reconciliação → rollback/rollforward → observação.