# Playbook — Mensageria
1. Identifique backlog/lag/erro/duplicidade/perda aparente.
2. Mapear producer, broker, consumer e side effect.
3. Verificar ack, retry, DLQ, idempotência e ordering.
4. Contenção reversível.
5. Teste hipótese.
6. Replay/reprocessamento apenas com proteção contra duplicidade.
7. Reconciliação final.
