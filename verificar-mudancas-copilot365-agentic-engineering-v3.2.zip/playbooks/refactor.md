# Refatoração
Proteger comportamento → baseline → mudança estrutural → regressão → confirmar ausência de mudança contratual não intencional.