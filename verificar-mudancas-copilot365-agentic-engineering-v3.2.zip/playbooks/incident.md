# Incidente
Impacto → evidência → contenção reversível → hipótese → experimento → recuperação → validação → aprendizado.