# Playbook — Migração de schema
1. Estado atual/alvo.
2. Consumidores N/N-1.
3. Expand/contract.
4. Backfill e reconciliação.
5. Rollback/rollforward.
6. Limites de lock/duração.
7. Métricas/sinais de sucesso.
8. Remoção de legado somente após coexistência validada.
