# Feature
Critérios de aceite → contratos → plano → testes derivados → implementação/especificação → integração → review → rollout/verificação.