# Playbook — Performance de banco
1. Query real + volume/cardinalidade.
2. Plano de execução.
3. Índices existentes.
4. Locks/conexões/tempo.
5. Hipótese: scan, N+1, join, índice, pool, contenção.
6. Alteração mínima.
7. EXPLAIN/benchmark antes/depois.
8. Verificar efeito em escrita/storage.
