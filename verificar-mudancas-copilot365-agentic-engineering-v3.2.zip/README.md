# Verificar Mudanças — Copilot 365 Agentic Engineering v3.2

Edição focada em **engenharia de software**, derivada do Agentic Full v3.1.

Mantém investigação, planejamento, arquitetura, TDD, implementação, review, segurança,
evidence gate, desenhos técnicos e aprendizado, com aprofundamento em:

- JVM / memória / GC;
- containers e serverless/Lambda;
- performance e benchmark;
- SRE e observabilidade;
- resiliência;
- bancos, SQL, índices e locks;
- migrações zero/baixo downtime;
- pipelines de dados;
- mensageria/event-driven;
- AWS;
- rede, ALB/NLB/TG;
- sistemas distribuídos;
- arquitetura/refatoração;
- evidência de mudança.

## Upload

Envie o ZIP completo em **Carregar habilidade** no Microsoft 365 Copilot Agent Builder.

Cole `INSTRUCOES-AGENTE-COPILOT365-AGENTIC-ENGINEERING-v3.2.txt`
no campo geral de instruções do agente.

## Filosofia

A estrutura `agents/`, `commands/` e `lifecycle/` representa papéis, intents e gates conceituais.
Não pressupõe subagentes, hooks, Git ou shell nativos quando o ambiente não os disponibiliza.
