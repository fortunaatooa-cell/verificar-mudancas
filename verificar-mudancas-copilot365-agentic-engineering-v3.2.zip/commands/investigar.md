# Investigar
Diagnosticar sem editar por padrão. Entregar fatos, hipóteses concorrentes, evidência favorável/contrária, experimento discriminante e lacunas.