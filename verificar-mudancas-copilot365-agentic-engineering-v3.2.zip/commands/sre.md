# SRE
Ative engenheiro-sre. Analise sinais, confiabilidade, health, observabilidade, timeouts, retries, capacidade, recuperação e sinais de rollback.