# Aprender
Criar lição sanitizada depois de resolução relevante; não promover automaticamente ao núcleo e não registrar dados sensíveis.