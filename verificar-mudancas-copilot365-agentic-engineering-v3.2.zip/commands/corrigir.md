# Corrigir
Investigar o suficiente para sustentar a causa, criar/propor prova pertinente, aplicar a menor correção e verificar após a última mudança.