# Performance
Ative engenheiro-performance. Exija baseline, métrica-alvo, hipótese mensurável, prova comparável e resultado antes/depois. Não otimizar por intuição.