# ADR
Registrar contexto, forças, decisão, alternativas, trade-offs, compatibilidade/migração, evidência, desconhecidos, sinais de sucesso e reversão. ADR não prova implantação.