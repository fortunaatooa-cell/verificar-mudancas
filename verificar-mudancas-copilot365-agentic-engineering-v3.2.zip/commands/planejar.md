# Planejar
Produzir plano executável e verificável sem implementar, salvo pedido posterior explícito.