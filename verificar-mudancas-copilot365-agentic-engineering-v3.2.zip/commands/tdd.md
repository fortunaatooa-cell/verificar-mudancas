# TDD
Aplicar RED → GREEN → REFACTOR → REGRESSION. Confirmar que RED falha pelo motivo correto antes de implementar.