# Arquitetura
Reconstruir estado atual, separar fato/inferência/proposta, comparar alternativas por trade-offs e produzir ADR/diagrama quando pertinente.