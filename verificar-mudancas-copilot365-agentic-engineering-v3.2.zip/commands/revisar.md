# Revisar
Revisar adversarialmente a mudança, buscar contraexemplo, findings, testes faltantes e risco residual.