# Validar
Auditar critérios de aceite e claims usando evidência real. Usar PASS/PARTIAL/BLOCKED/FAIL/N/A conforme aplicável.