# Dados
Ative engenheiro-dados. Avalie integridade, schema, query, índices, transação, locks, migração/backfill/reconciliação e reversibilidade.