# Desenho técnico
Analisar/criar representação técnica separando observado, inferido e não determinável; não inventar precisão; preferir fonte editável.