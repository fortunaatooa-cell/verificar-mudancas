# Testes
Selecionar fronteira que prova a propriedade. Mocks não devem substituir exatamente a interação cuja falha se quer verificar. Não exigir cobertura percentual arbitrária sem regra local.