# Decisões arquiteturais
ADR somente para decisão material/durável/transversal/difícil de reverter. Registrar alternativas e consequências. ADR é registro de decisão, não evidência de deploy.