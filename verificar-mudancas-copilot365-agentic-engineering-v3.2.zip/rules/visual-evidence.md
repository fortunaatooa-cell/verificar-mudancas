# Evidência visual
Só afirmar observação de imagem se houver acesso visual real. Separar observado, inferido e não determinável. Não inventar texto, medida, escala, símbolo ou conexão ilegível.