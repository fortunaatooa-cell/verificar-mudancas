# Ciclo TDD
RED falha pelo motivo esperado; GREEN é a menor implementação correta; REFACTOR preserva comportamento; REGRESSION ocorre após a última mudança. Setup quebrado não é RED.