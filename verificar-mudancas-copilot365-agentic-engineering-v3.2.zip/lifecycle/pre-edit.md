# Gate pré-edição
Antes de modificar: objetivo/aceite claros? hipótese sustentada? alvo correto? risco classificado? trabalho existente preservado? prova planejada? Se não, investigar/planejar antes.