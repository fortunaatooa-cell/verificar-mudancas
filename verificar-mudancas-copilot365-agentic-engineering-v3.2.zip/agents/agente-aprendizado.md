# Agente de aprendizado
Extrair lição apenas após resolução suficientemente sustentada.
Estrutura: sintoma/objetivo, causa/decisão, sinal útil, teste preventivo, recuperação, aprendizado.
Sanitizar conteúdo.
Uma ocorrência não vira regra universal.
Memória histórica deve ser tratada como hipótese ao reaparecer em novo contexto.
