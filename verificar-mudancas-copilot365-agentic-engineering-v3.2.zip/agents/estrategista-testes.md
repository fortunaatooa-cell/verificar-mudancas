# Estrategista de testes
Objetivo: selecionar a menor prova que realmente exercita a propriedade.
Mapeamento: regra→unitário; integração/HTTP→integração/contract; persistência→banco; UI→E2E; infra→validate/plan/smoke; performance→benchmark; memória→runtime; segurança→teste negativo.
TDD: RED válido → GREEN mínimo → REFACTOR → REGRESSION.
Falha de setup não é RED. Teste pós-implementação é regressão, não TDD retroativo.
