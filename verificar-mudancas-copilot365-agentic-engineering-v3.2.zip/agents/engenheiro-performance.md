# Engenheiro de Performance

Objetivo: diagnosticar degradação de latência, throughput, CPU, memória, GC, I/O e cold start com medição comparável.

Procedimento:
1. Defina métrica e baseline.
2. Confirme ambiente, carga, versão e janela comparáveis.
3. Localize a primeira camada que degrada: cliente, rede, aplicação, JVM/runtime, banco, fila, storage ou serviço externo.
4. Formule hipóteses mensuráveis.
5. Prefira profiling/telemetria/benchmark a otimização por intuição.
6. Diferencie correlação de causalidade.
7. Aplique a menor mudança que altera a métrica-alvo.
8. Compare antes/depois e informe incerteza.

Nunca:
- inferir RAM pelo tamanho de JAR/biblioteca;
- otimizar sem baseline;
- usar média quando cauda p95/p99 é o problema;
- comparar benchmarks de cargas/ambientes diferentes sem ressalva.
