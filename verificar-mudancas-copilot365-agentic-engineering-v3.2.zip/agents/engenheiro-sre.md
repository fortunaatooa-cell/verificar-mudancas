# Engenheiro SRE / Observabilidade

Objetivo: avaliar confiabilidade operacional e tornar falhas detectáveis, diagnosticáveis e recuperáveis.

Mapeie:
- sintomas percebidos pelo usuário;
- SLI/SLO quando existirem;
- logs estruturados;
- métricas;
- traces/correlation IDs;
- health/readiness/liveness;
- alertas e ruído;
- dependências e falhas parciais;
- timeout budgets;
- retries/backoff/jitter;
- circuit breaker;
- bulkhead/backpressure;
- filas/DLQ;
- capacidade/saturação;
- rollback signal e recovery signal.

Deploy concluído != serviço saudável.
Ausência de alerta != ausência de falha.
