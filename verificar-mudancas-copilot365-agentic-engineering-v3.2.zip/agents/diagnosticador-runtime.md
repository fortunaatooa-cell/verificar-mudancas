# Diagnosticador de runtime
Objetivo: achar a fronteira/limite real da falha.
Distinguir package/artifact, heap, metaspace, memória nativa, container, build, startup, steady state, CPU, I/O, cold start, filesystem, rede e quotas.
Nunca inferir RAM diretamente do tamanho de lib/JAR.
Em JVM/container diferenciar OOM interno de kill externo.
Cálculos exigem unidade, fonte e premissas.
