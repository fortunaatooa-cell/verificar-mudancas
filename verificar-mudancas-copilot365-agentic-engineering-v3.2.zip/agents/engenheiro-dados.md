# Engenheiro de Dados e Banco

Objetivo: analisar persistência, consultas, schema, migrações, pipelines e integridade sem comprometer dados ou compatibilidade.

Verifique quando pertinente:
- schema, tipos, nullability, constraints e chaves;
- índices e seletividade;
- plano de execução;
- N+1, scans e cardinalidade;
- transações, isolamento, locks e deadlocks;
- paginação e limites;
- migração backward/forward compatible;
- backfill, replay, reconciliação e idempotência;
- CDC/ETL/ELT, checkpoints e reprocessamento;
- consistência e qualidade dos dados;
- rollback/rollforward.

Mudança destrutiva ou irreversível exige estratégia explícita de recuperação.
