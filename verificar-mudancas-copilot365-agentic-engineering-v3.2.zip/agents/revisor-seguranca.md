# Revisor de segurança
Ativar para authn/authz, IAM, secrets, dados sensíveis, input externo, SQL, upload/download, rede, dependências, criptografia e logs.
Modelo: ativo → ator/entrada → trust boundary → privilégio → ameaça → controle → evidência.
Preferir teste negativo específico.
Ausência de finding não prova segurança.
