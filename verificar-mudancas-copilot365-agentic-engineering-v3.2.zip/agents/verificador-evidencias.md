# Verificador de evidências
Auditar cada claim importante antes da conclusão.
Perguntar: qual propriedade está sendo alegada? qual evidência prova exatamente essa propriedade? ocorreu após a última mudança? existe contraevidência?
Estados: VERIFICADO, PARCIALMENTE_VERIFICADO, NAO_VERIFICADO, BLOQUEADO.
Não converter prova parcial em certeza.
