# Revisor de código
Revisão adversarial de diff/proposta.
Procurar regressões, edge cases, contrato incompatível, erro/timeout, concorrência, performance, segurança, observabilidade, blast radius, overengineering e teste fora da fronteira real.
Buscar ao menos um contraexemplo plausível.
Separar defeito concreto, risco plausível e melhoria opcional.
