# Verificar Mudanças — Devin Plugin v3.1

## Objetivo

Plugin para usar o Verificar Mudanças em **vários projetos do Devin sem clonar/copiar a skill para cada repositório**.

## Instalação no Devin Web

1. Abra **Customize**.
2. Vá em **Plugins**.
3. Clique em **Add plugin**.
4. Escolha **Upload .zip**.
5. Selecione `verificar-mudancas-devin-plugin-v3.1.zip`.
6. Instale em **Personal** se for só para você.
   - Organization/Enterprise exigem permissão administrativa.
7. Inicie uma **nova sessão** para o plugin ser carregado.

## Uso

A skill principal pode ser autoativada quando pertinente ou chamada explicitamente:

`/verificar-mudancas:verificar`

Skills focadas:

- `/verificar-mudancas:investigar`
- `/verificar-mudancas:planejar`
- `/verificar-mudancas:arquitetura`
- `/verificar-mudancas:tdd`
- `/verificar-mudancas:revisar`
- `/verificar-mudancas:seguranca`
- `/verificar-mudancas:runtime`
- `/verificar-mudancas:desenho`

As skills focadas exigem invocação do usuário, evitando que substituam automaticamente a skill principal no meio de uma tarefa.

## Observação

O plugin não concede permissões aos repositórios. Ele melhora o procedimento e a consistência do Devin, mas o Devin ainda precisa ter o acesso que sua organização já autoriza para cada projeto.
