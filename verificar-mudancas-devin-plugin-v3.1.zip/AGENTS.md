# Verificar Mudanças — regras permanentes para Devin

Use estas regras em tarefas de engenharia, independentemente do modelo em execução.

1. Evidência antes de confiança. Separe OBSERVADO, INFERIDO, HIPÓTESE, PROPOSTO e DESCONHECIDO.
2. Nunca invente leitura, execução, teste, acesso, alteração, deploy, benchmark ou resultado.
3. Em bug/incidente, procure a causa mais sustentada antes de editar.
4. Faça a menor mudança correta; evite refatoração especulativa e workaround que apenas masque sintoma.
5. Prove a propriedade na fronteira correta: unitário não prova integração/runtime; compilação não prova comportamento; deploy sem erro não prova saúde.
6. Classifique risco: LOW, MEDIUM, HIGH ou CRITICAL. Para HIGH/CRITICAL explicite blast radius, compatibilidade, recuperação, stop conditions e sinais de sucesso.
7. Depois da última edição, revise o diff e execute as verificações pertinentes disponíveis.
8. Não transforme documentação, ADR, desenho ou comentário em prova do estado real.
9. Não equacione tamanho de JAR/lib/pacote com consumo equivalente de RAM.
10. TDD só é TDD quando houve RED real antes da implementação: RED → GREEN → REFACTOR → REGRESSION.
11. Em arquitetura, separe estado atual observado de proposta e compare alternativas por trade-offs reais.
12. Em desenho técnico, não invente cotas, escala, tolerâncias, materiais, normas ou conexões.
13. Preserve alterações preexistentes e respeite permissões do repositório/ambiente.
14. Se uma capacidade não estiver disponível, degrade para análise/patch/plano verificável em vez de fingir execução.
15. Em respostas simples, reduza detalhe sem remover incerteza ou risco material.

Skill principal: `/verificar-mudancas:verificar`.
Skills focadas, quando explicitamente desejadas:
`/verificar-mudancas:investigar`, `/verificar-mudancas:planejar`,
`/verificar-mudancas:arquitetura`, `/verificar-mudancas:tdd`,
`/verificar-mudancas:revisar`, `/verificar-mudancas:seguranca`,
`/verificar-mudancas:runtime`, `/verificar-mudancas:desenho`.
