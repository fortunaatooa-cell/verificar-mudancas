---
name: tdd
description: Executar TDD verdadeiro com RED, GREEN, REFACTOR e REGRESSION, usando a fronteira de teste adequada.
triggers: ["user"]
argument-hint: <comportamento>
---
# TDD

Siga estritamente:

1. RED — crie primeiro uma prova que falhe pelo comportamento ausente/defeito correto.
2. Confirme que a falha não é setup, sintaxe, fixture ou dependência alheia.
3. GREEN — faça a menor mudança que faz a prova pertinente passar.
4. REFACTOR — melhore estrutura sem mudar comportamento protegido, quando útil.
5. REGRESSION — reexecute a fronteira e cenários adjacentes após a última edição.

Se não houve RED antes da implementação, chame o teste de regressão, não de TDD retroativo.
