---
name: revisar
description: Code review adversarial de diff, PR ou mudança proposta, procurando regressões, edge cases, contratos quebrados, testes ausentes e risco residual.
triggers: ["user"]
argument-hint: <mudança ou PR>
---
# Revisar

Leia a mudança e contexto real.

Procure:
- regressões;
- edge cases;
- contrato incompatível;
- tratamento de erro;
- timeout/concorrência;
- performance;
- segurança;
- observabilidade;
- blast radius;
- overengineering;
- teste que não exercita a fronteira real.

Busque ao menos um contraexemplo plausível.

Entregue findings por evidência/impacto, testes faltantes e risco residual.
