---
name: investigar
description: Investigação read-first para bugs, incidentes, regressões e comportamentos inesperados. Use quando o usuário quer causa raiz ou diagnóstico antes de qualquer mudança.
triggers: ["user"]
argument-hint: <problema>
---
# Investigar

Não edite por padrão.

1. Defina esperado e observado.
2. Localize o primeiro ponto de divergência.
3. Liste fatos observáveis.
4. Formule ao menos duas hipóteses quando houver ambiguidade real.
5. Busque evidência favorável e contrária.
6. Defina o experimento que melhor diferencia hipóteses.
7. Rejeite hipóteses invalidadas.
8. Entregue hipótese mais forte e lacunas.

Não confunda documentação com runtime, correlação com causa ou ausência de evidência com ausência do problema.
