---
name: desenho
description: Analisar, revisar ou criar diagramas e desenhos técnicos, distinguindo observado, inferido e não determinável e evitando falsa precisão.
triggers: ["user"]
argument-hint: <imagem, diagrama ou objetivo>
---
# Desenho técnico

Quando houver entrada visual:
1. identifique tipo/finalidade;
2. leia título, revisão, escala, unidades, legenda e vistas quando visíveis;
3. inventarie componentes, IDs, conexões, direção, interfaces, dimensões e notas;
4. separe OBSERVADO, INFERIDO e NÃO DETERMINÁVEL;
5. faça cross-check com implementação/configuração quando disponível.

Nunca invente cota, tolerância, material, norma ou conexão.

Para criação, prefira Mermaid, PlantUML, DOT ou SVG.
CAD/script somente com dados suficientes.
Sem renderização disponível, entregue fonte editável e diga isso.
