---
name: verificar
description: Use para tarefas de engenharia de software que envolvam investigar, planejar, corrigir, implementar, testar, revisar ou validar mudanças com evidência. Também cobre arquitetura, segurança, runtime, performance, APIs, dados, cloud e desenhos técnicos.
argument-hint: <tarefa de engenharia>
---

# Verificar Mudanças

Conduza a tarefa usando **evidência verificável**, profundidade proporcional ao risco e a menor mudança correta.

## 1. Entenda antes de agir

Determine apenas o que for material:
- objetivo;
- esperado vs. observado;
- impacto;
- ambiente/versão;
- fronteira afetada;
- restrições;
- evidências disponíveis;
- o que já foi tentado.

Se o contexto do repositório estiver disponível, leia instruções locais, inspecione o estado atual e preserve trabalho preexistente.

Não peça detalhes que não mudariam a decisão.

## 2. Detecte capacidades reais

Use apenas capacidades realmente disponíveis na sessão.

Se houver repo/terminal/testes:
- inspecione antes de editar;
- descubra comandos reais;
- execute provas relevantes;
- revise o diff depois.

Se não houver escrita ou execução:
- produza patch/snippet/plano;
- marque execução como NÃO REALIZADA;
- diga exatamente como provar.

Nunca invente ação ou resultado.

## 3. Classifique tarefa e risco

Tipo dominante:
bug, feature, refatoração, migração, incidente, upgrade, performance, dados, infraestrutura, arquitetura, desenho técnico, investigação ou revisão.

Critérios de aceite devem ser observáveis:
- comportamento que deve existir;
- comportamento que deve permanecer;
- erro/limite pertinente;
- fronteira da prova.

Risco:
- LOW: local, reversível;
- MEDIUM: vários módulos ou integração interna;
- HIGH: contrato externo, segurança, dados persistentes, infra, migração ou impacto operacional;
- CRITICAL: destruição/irreversibilidade, produção de alto impacto, privilégio sensível ou perda potencial de dados.

Para HIGH/CRITICAL: blast radius, compatibilidade, rollback/rollforward, stop conditions e sinais de sucesso.

## 4. Investigue antes de corrigir

Em bug/incidente:

1. localize o primeiro ponto de divergência;
2. registre fatos;
3. formule hipóteses concorrentes;
4. procure evidência favorável e contrária;
5. defina experimento que possa refutar;
6. rejeite hipóteses invalidadas;
7. declare lacunas.

Não editar por tentativa e erro quando uma prova discriminante for viável.

Não chamar correlação de causa.

## 5. Planeje conforme a complexidade

Para mudança ampla, explicite:
- objetivo;
- escopo e fora de escopo;
- restrições/premissas;
- desconhecidos;
- componentes/contratos prováveis;
- dependências e ordem;
- critérios de aceite;
- estratégia de prova;
- riscos;
- stop conditions.

Não invente componente, arquivo ou requisito ausente como fato.

Para mudança pequena e sustentada, mantenha o plano curto.

## 6. Arquitetura

Reconstrua primeiro o estado atual e rotule:
- OBSERVADO;
- INFERIDO;
- DESCONHECIDO.

Somente depois use PROPOSTO.

Mapeie quando pertinente:
- componentes;
- contratos;
- dependências;
- fluxo de dados;
- trust boundaries;
- armazenamento;
- consistência;
- observabilidade/operação.

Compare alternativas por forças reais:
latência, throughput, disponibilidade, consistência, custo, segurança, complexidade operacional, compatibilidade, migração, reversibilidade e prazo.

Não force vencedor quando requisitos faltantes impedirem comparação objetiva.

Decisão estrutural/durável pode gerar ADR:
contexto, forças, decisão, alternativas, consequências, migração, evidências e reversão.

ADR registra decisão; não prova implantação.

## 7. Testes e TDD

Escolha a prova pela propriedade:
- regra isolada → unitário;
- HTTP/integração → integração/contract;
- persistência → banco realista;
- mensageria → integração/contrato;
- UI → E2E/runtime;
- infraestrutura → validate/plan + smoke autorizado;
- performance → benchmark comparável;
- memória → medição runtime;
- segurança → teste negativo pertinente.

Um teste verde fora da fronteira não prova a mudança.

### TDD

Quando TDD for pedido/apropriado:

**RED → GREEN → REFACTOR → REGRESSION**

RED precisa falhar pelo comportamento ausente/defeito correto.
Falha de setup, sintaxe, fixture ou dependência alheia não é RED válido.
Teste escrito depois da implementação é regressão, não RED histórico.

## 8. Implemente a menor mudança correta

Quando a causa/plano estiver sustentado:
- respeite padrões reais do projeto;
- preserve contratos necessários;
- evite refatoração especulativa;
- não amplie escopo sem necessidade;
- não ajuste teste apenas para acompanhar uma implementação errada.

Se nova evidência invalidar a hipótese, volte à investigação.

## 9. Faça review adversarial

Depois da mudança/proposta, procure:
- regressões;
- edge cases;
- quebra de contrato;
- tratamento de erro;
- timeout;
- concorrência;
- performance;
- segurança;
- observabilidade;
- blast radius;
- overengineering;
- testes que não exercitam a fronteira real.

Busque ao menos um contraexemplo plausível.

Quando houver auth, IAM, secrets, dados sensíveis, input externo, SQL, upload/download, rede, dependências ou criptografia, faça revisão de segurança específica.

## 10. Runtime e performance

Diferencie:
- artifact/JAR/package size;
- heap;
- metaspace;
- native memory;
- memória do container;
- memória de build;
- startup;
- steady state;
- CPU;
- I/O;
- cold start;
- limites externos.

**Tamanho de JAR/lib não equivale ao mesmo consumo de RAM.**

Antes de recomendar mais recurso, identifique qual processo/limite falhou.

Em JVM/container, diferencie `OutOfMemoryError` da JVM de kill externo.

Cálculos devem indicar unidade, origem e premissas.

Performance exige baseline comparável.

Deploy concluído sem erro não prova saúde.

## 11. APIs, dados, cloud e distribuídos

Quando pertinente, verifique:
- método/path/status/headers/schema;
- contrato e consumidor real;
- compatibilidade/versionamento;
- idempotência;
- timeout/retry;
- schema/constraints/índices;
- transações/locks;
- migração/backfill/replay/reconciliação;
- duplicidade/ordem/DLQ/consistência eventual;
- conta/região/workspace/target;
- Terraform plan/replacement/destruição;
- artifact e ambiente do pipeline.

CI verde não prova produção.
Terraform desejado não prova estado implantado.

## 12. Desenhos técnicos

Se houver entrada visual real:
1. identifique tipo/finalidade;
2. procure título, revisão, escala, unidades, legenda, vistas/cortes;
3. inventarie componentes, IDs, conexões, direção, interfaces, dimensões e notas;
4. separe OBSERVADO, INFERIDO e NÃO DETERMINÁVEL;
5. faça cross-check com implementação/configuração quando possível.

Nunca invente cota, tolerância, material, norma ou conexão.

Para criar/redesenhar, prefira fonte editável:
Mermaid, PlantUML, DOT ou SVG.
CAD/script somente com dados geométricos suficientes.

## 13. Verifique antes de concluir

Depois da última alteração, execute o conjunto pertinente:
- testes afetados;
- build;
- lint;
- integração/contract;
- smoke/E2E;
- benchmark;
- plan/diff;
- runtime signals.

Revise diff/status quando disponíveis.

Para claims materiais, use:
- Claim
- Evidência
- Estado: VERIFICADO | PARCIALMENTE_VERIFICADO | NAO_VERIFICADO | BLOQUEADO
- Lacuna
- Próxima prova

Não diga “corrigido”, “seguro”, “deploy funcionando” ou “performance melhorou” sem evidência compatível.

## 14. Stop conditions

Pare ação destrutiva/externa e reavalie se:
- ambiente/conta/região/workspace/target não estiver claro;
- surgir destruição/replacement/perda de dados inesperada;
- houver ampliação de privilégio inesperada;
- segredo/dado sensível estiver exposto;
- experimento invalidar a hipótese;
- escopo crescer materialmente;
- ação irreversível não tiver recuperação/autorização suficiente;
- houver risco de sobrescrever trabalho de terceiros.

Continue com análise segura e próximo passo verificável.

## 15. Formato de resposta

Escolha conforme necessidade.

### Simples
Conclusão + evidência essencial + risco/lacuna + próximo passo.

### Aprofundado
Contexto + evidências + hipóteses + análise + alternativas + mudança/plano + prova + riscos.

### Ambos
Resumo simples autossuficiente e depois análise completa.

Modo simples reduz volume, nunca rigor.
