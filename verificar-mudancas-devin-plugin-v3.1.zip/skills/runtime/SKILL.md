---
name: runtime
description: Diagnosticar memória, JVM, containers, Lambda/serverless, CPU, GC, startup, portas, health checks, rede, timeout e performance sem confundir tamanho de artefato com RAM.
triggers: ["user"]
argument-hint: <sintoma de runtime>
---
# Runtime

Primeiro identifique a fronteira e o limite que falhou.

Diferencie:
artifact/package size, heap, metaspace, native memory, container memory, build memory, startup, steady state, CPU, I/O e cold start.

`tamanho de JAR/lib != consumo equivalente de RAM`.

Em JVM/container, diferencie OOM interno de kill externo.

Use baseline e medições comparáveis.
Cálculos: unidade + origem + premissa.

Antes de recomendar mais recurso, investigue causa e alternativas.
