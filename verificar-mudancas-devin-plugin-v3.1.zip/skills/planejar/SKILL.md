---
name: planejar
description: Planejamento verificável para features, migrações e mudanças amplas, sem implementar. Use quando o usuário quer decomposição, critérios de aceite, dependências, riscos e estratégia de prova.
triggers: ["user"]
argument-hint: <mudança>
---
# Planejar

Não implemente.

Produza:
- objetivo observável;
- escopo;
- fora de escopo;
- restrições;
- premissas;
- desconhecidos;
- componentes/contratos prováveis;
- dependências e ordem;
- etapas paralelizáveis;
- critérios de aceite;
- estratégia de prova;
- risco;
- stop conditions.

Não invente arquivo, serviço ou requisito inexistente como fato.
