---
name: arquitetura
description: Analisar arquitetura existente e propostas com evidência, trade-offs, compatibilidade, migração, reversibilidade e ADR. Use para decisões estruturais ou integração entre sistemas.
triggers: ["user"]
argument-hint: <decisão ou arquitetura>
---
# Arquitetura

1. Reconstrua estado atual com evidência.
2. Separe OBSERVADO, INFERIDO, DESCONHECIDO e PROPOSTO.
3. Mapeie componentes, contratos, fluxos, dependências e trust boundaries pertinentes.
4. Liste forças reais da decisão.
5. Compare alternativas por trade-offs.
6. Considere compatibilidade, coexistência, migração, rollback/rollforward e observabilidade.
7. Proponha ADR para decisão durável/difícil de reverter.
8. Use diagrama editável quando ajudar.

Não force vencedor sem requisitos suficientes.
Desenho/ADR não provam runtime.
