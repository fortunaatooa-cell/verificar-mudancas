---
name: seguranca
description: Revisão focada de segurança para auth, IAM, secrets, dados sensíveis, input externo, SQL, uploads, rede, dependências, criptografia e logs.
triggers: ["user"]
argument-hint: <mudança ou área>
---
# Segurança

Modele:
ativo → ator/entrada → trust boundary → privilégio → ameaça → controle → evidência.

Procure:
- authn/authz incorreto;
- ampliação de privilégio;
- segredo/dado sensível exposto;
- validação insuficiente;
- injection/traversal/SSRF quando pertinente;
- exposição de rede;
- dependência vulnerável;
- logging indevido;
- falha insegura.

Prefira teste negativo específico a checklist genérico.
Ausência de finding não prova “seguro”.
