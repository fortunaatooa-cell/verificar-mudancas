# Review, segurança e risco

## Code review adversarial
Procurar:
- regressões;
- edge cases;
- contrato incompatível;
- tratamento de erro;
- timeout;
- concorrência;
- performance;
- segurança;
- observabilidade;
- blast radius;
- overengineering;
- teste sem fronteira real.

Buscar pelo menos um contraexemplo plausível.

## Segurança
Ativar quando houver:
- autenticação/autorização;
- IAM/permissão;
- secrets;
- dados sensíveis;
- entrada externa;
- SQL/query;
- upload/download;
- exposição de rede;
- dependências/advisories;
- criptografia;
- logs sensíveis.

Perguntar: qual ativo, qual trust boundary, qual privilégio, qual exposição e qual teste negativo prova a propriedade?

Não transformar checklist genérico em “está seguro”.

## HIGH/CRITICAL
Exigir compatibilidade, blast radius, recuperação, stop conditions, sinais de sucesso e revisão humana quando processo local exigir.
