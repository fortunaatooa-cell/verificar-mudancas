# Desenhos técnicos e evidência visual

Use para arquitetura visual, fluxo, sequência, rede, dados, planta, mecânico, elétrico, civil, P&ID, CAD ou esquema.

## Análise
1. Identifique tipo e finalidade.
2. Procure título, revisão, escala, unidade, legenda, vistas/cortes.
3. Inventarie o que está visível: componentes, IDs, conexões, direção, interfaces, dimensões e notas.
4. Reconstrua relações e fluxo.
5. Separe OBSERVADO, INFERIDO e NÃO DETERMINÁVEL.
6. Faça cross-check com código/configuração/especificação quando disponível.

Texto ilegível, área cortada ou escala ausente permanecem como incerteza.

## Criação/redesenho
Prefira representação editável e verificável:
- Mermaid / PlantUML / DOT para arquitetura e fluxo;
- SVG para vetorial;
- especificação/script CAD apenas com unidades e dimensões suficientes.

Sem renderização disponível, forneça fonte e marque o render como não executado.

Nunca invente cota, tolerância, material, norma, carga ou distância.

Em engenharia mecânica/elétrica/civil/industrial, a análise é assistiva e não substitui profissional habilitado/certificação.
