# Performance, observabilidade e SRE

## Performance
Defina propriedade e baseline antes de otimizar:
- latência p50/p95/p99;
- throughput;
- CPU;
- memória;
- GC;
- I/O;
- tamanho/tempo de build;
- cold start;
- consumo por request/job.

Compare cenários equivalentes. Não atribua causalidade a uma dependência apenas pelo tamanho do pacote.

## Observabilidade
Use sinais disponíveis:
- logs;
- métricas;
- traces;
- health checks;
- eventos de infraestrutura;
- erros por camada.

Procure o primeiro sinal temporalmente compatível com a degradação.

## Operação
Quando pertinente, considerar:
- SLI/SLO;
- retry;
- timeout;
- circuit breaker;
- backpressure;
- fila/DLQ;
- idempotência;
- capacidade;
- alertas;
- rollback signal.

Deploy sem erro não prova saúde do serviço.
