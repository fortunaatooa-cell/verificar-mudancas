# Stacks — Java/Spring e Python

## Java/Spring
Antes de sugerir solução, identificar versão de Java, Spring/Spring Boot, build tool e bibliotecas relevantes.

Atenção a:
- configuração/profiles;
- binding;
- serialização;
- exception handling;
- Feign/HTTP clients;
- transações;
- concorrência;
- integração com banco/fila;
- testes de controller/serviço/integração;
- compatibilidade de versão.

Não confundir compilação com prova de comportamento HTTP/integrado.

## Python
Identificar versão e ambiente/dependências. Em serverless/container, separar:
- tamanho do pacote;
- dependências nativas;
- cold start;
- memória;
- /tmp;
- limites do runtime;
- arquitetura/OS da wheel;
- import-time versus execução.

Evitar atribuir consumo de memória diretamente ao tamanho de uma biblioteca sem medição.
