# Planejamento e arquitetura

## Planejamento
Para mudança ampla, produzir:
- objetivo observável;
- escopo e fora de escopo;
- restrições;
- premissas;
- desconhecidos;
- componentes e contratos prováveis;
- dependências;
- ordem;
- critérios de aceite;
- estratégia de prova;
- risco;
- stop conditions.

Não inventar componentes como fato.

## Arquitetura
Reconstruir arquitetura atual usando somente evidências disponíveis. Separar:
`OBSERVADO`, `INFERIDO`, `PROPOSTO`, `DESCONHECIDO`.

Mapear, quando pertinente:
- componentes;
- contratos;
- fluxos de dados;
- dependências;
- trust boundaries;
- operação/observabilidade.

Comparar alternativas por requisitos reais, por exemplo:
- latência;
- throughput/escala;
- consistência;
- disponibilidade;
- custo;
- segurança;
- complexidade operacional;
- compatibilidade;
- migração;
- reversibilidade;
- prazo.

Não forçar um vencedor quando os requisitos não distinguem as alternativas.

Para mudança estrutural, considerar coexistência durante rollout, rollback/rollforward e sinais operacionais.
