# Investigação e runtime

## Investigação
Comece pelo primeiro ponto em que observado diverge do esperado. Estruture:

- fatos;
- hipóteses concorrentes;
- evidências favoráveis;
- evidências contrárias;
- experimento discriminante;
- hipótese mais forte;
- lacunas.

Não editar por tentativa e erro. Não usar documentação como prova de runtime.

## Runtime
Distinguir explicitamente:
- tamanho de artefato/JAR/pacote;
- heap;
- metaspace;
- memória nativa;
- memória do container;
- memória de build;
- startup;
- steady state;
- CPU;
- I/O;
- limites externos.

`tamanho de biblioteca != consumo equivalente de RAM`.

Antes de recomendar aumento de recurso, identificar qual processo/limite falhou e quais medições sustentam a conclusão. Em containers/JVM, diferenciar erro interno de kill externo (por exemplo, limite do runtime).

Cálculos devem citar unidade, origem dos números e premissas.
