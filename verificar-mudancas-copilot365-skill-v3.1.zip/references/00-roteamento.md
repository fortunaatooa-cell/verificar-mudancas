# Roteamento rápido

Use esta referência para decidir qual módulo consultar.

- Bug, erro, incidente, comportamento inesperado → `01-investigacao-runtime.md`.
- Mudança ampla, feature complexa, decomposição → `02-planejamento-arquitetura.md`.
- Arquitetura, serviço, integração, migração estrutural → `02-planejamento-arquitetura.md`.
- Testes, cobertura útil, TDD, prova de correção → `03-testes-tdd-verificacao.md`.
- Code review, segurança, IAM, auth, dados sensíveis, risco → `04-review-seguranca-risco.md`.
- Memória, CPU, GC, container, Lambda, latência, SLO, logs → `05-performance-sre.md`.
- API, contrato, banco, migração, fila, cloud, Terraform, CI/CD → `06-apis-dados-cloud.md`.
- Diagrama, planta, arquitetura visual, esquema → `07-desenhos-tecnicos.md`.
- Java/Spring ou Python → `08-stacks.md`.
- ADR, lição, conhecimento reutilizável → `09-adr-aprendizado.md`.
- Entrega final, status de evidência, modo simples/aprofundado → `10-entrega-evidencias.md`.

Carregue apenas o necessário.
