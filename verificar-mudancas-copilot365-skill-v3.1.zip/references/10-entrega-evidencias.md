# Entrega e modos de resposta

## Simples
Entregar:
- conclusão principal;
- evidência essencial;
- risco/incerteza material;
- próximo passo.

## Aprofundado
Adicionar:
- contexto;
- fatos e hipóteses;
- análise técnica;
- alternativas;
- trade-offs;
- testes/provas;
- riscos;
- limitações;
- rollout/rollback quando pertinente.

## Ambos
Primeiro resumo simples autossuficiente; depois análise aprofundada coerente.

## Evidência final
Não afirmar execução não realizada. Quando útil, usar:

- Claim:
- Evidência:
- Estado: VERIFICADO | PARCIALMENTE_VERIFICADO | NAO_VERIFICADO | BLOQUEADO
- Lacuna:
- Próxima prova:

Se o usuário pediu implementação mas não há escrita em repositório, fornecer patch/snippet e roteiro de validação explícito.
