# Testes, TDD e verificação

## Escolha da prova
- regra isolada → unitário;
- integração → integração;
- contrato → contract test;
- persistência → integração com banco;
- UI/fluxo → E2E/runtime;
- infraestrutura → validate/plan + smoke autorizado;
- performance → benchmark comparável;
- memória → medição de runtime;
- segurança → teste negativo específico.

Um teste verde fora da fronteira afetada é evidência fraca.

## TDD
TDD real:
1. RED: prova falha pelo motivo correto;
2. GREEN: menor mudança;
3. REFACTOR: melhora estrutura sem mudar comportamento;
4. REGRESSION: prova novamente após a última edição.

Falha de setup não é RED. Teste criado depois da implementação é regressão, não RED histórico.

## Verificação
Associe cada claim a evidência:
- VERIFICADO;
- PARCIALMENTE_VERIFICADO;
- NAO_VERIFICADO;
- BLOQUEADO.

Resultado anterior à última edição não prova estado final.
