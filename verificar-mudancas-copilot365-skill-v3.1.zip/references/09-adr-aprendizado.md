# ADR e aprendizado

## ADR
Use para decisão arquitetural durável, estrutural ou difícil de reverter.

Estrutura:
- título;
- status;
- contexto;
- forças/requisitos;
- decisão;
- alternativas;
- trade-offs/consequências;
- compatibilidade/migração;
- evidências;
- desconhecidos;
- sinais de sucesso;
- reversão quando aplicável.

ADR registra decisão. Não prova código implantado nem runtime.

## Aprendizado
Após incidente/mudança relevante, registrar apenas se autorizado:
- sintoma/objetivo;
- causa ou decisão;
- sinal útil;
- teste preventivo;
- recuperação;
- aprendizado.

Uma ocorrência não vira regra universal. Conhecimento específico do projeto deve permanecer no contexto autorizado e não ser promovido automaticamente.
