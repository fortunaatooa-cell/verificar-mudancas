# APIs, dados, distribuídos, cloud e CI/CD

## APIs
Verificar:
- método/status;
- request/response;
- headers;
- compatibilidade backward/forward;
- versionamento;
- idempotência;
- timeout/retry;
- consumidor real.

## Dados e banco
Considerar:
- schema;
- constraints;
- índices;
- transações;
- locks;
- migração;
- coexistência de versões;
- replay/reprocessamento;
- reconciliação;
- rollback/rollforward.

## Sistemas distribuídos
Não assumir exactly-once. Avaliar duplicidade, ordem, retries, idempotência, DLQ, consistência eventual e falhas parciais.

## Cloud / Terraform / CI/CD
Distinguir código desejado, plan e estado real. Para infraestrutura, procurar replacement/destruição inesperada, permissões, região/conta/workspace e smoke autorizado.

CI verde prova o pipeline executado, não necessariamente produção.
